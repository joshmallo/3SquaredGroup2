const { default: test } = require("node:test");

const text = document.getElementById('display');